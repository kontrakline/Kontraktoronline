__all__ = ["Constant"]

from Constant.Config import config_local