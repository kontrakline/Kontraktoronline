class HToken(object):

    def __init__(self):
        self.id = None
        self.email = None
        self.Ip_address = None
        self.imei = None