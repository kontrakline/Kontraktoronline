import logging
import json
from Route import RToken
from Holder.HResponse import HResponse
from Helper import ResponseHelper

def lambda_handler(pParam):

    function = pParam["function"]
    param    = pParam["data"]
    response = HResponse()

    try :
        command = getattr(RToken(param), function)
        response = command()
    except Exception as e :
        print(e)

    return ResponseHelper.formatJSON(response)


# if __name__ == "__main__" :
#     param = {"function": "encodeToken", "data": {"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50X2lkIjoxfQ.IpRROKVMnIOoJOGLJH3I6-OBTkqreWGQlxfPoJVKeas"}}
#     print(lambda_handler(param))