__all__ = ["Service"]

from Service.SCurl import SCurl
from Service.Microservice import Microservice