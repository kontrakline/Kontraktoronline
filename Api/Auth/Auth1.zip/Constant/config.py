class config_default:
    TOKEN = ""
    DB_MODULE_ACCOUNT = ""

class config_staging:

    TOKEN = 'https://93cmy8siz7.execute-api.ap-southeast-1.amazonaws.com/staging/token'
    DB_MODULE_ACCOUNT_NEW = 'https://93cmy8siz7.execute-api.ap-southeast-1.amazonaws.com/staging/account'
