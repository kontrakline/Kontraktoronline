class en(object):

    def signin(self):
        data= {
            'completion' : 'Please fill the blank.',
            'wrongpassword' : 'Make sure you use right password'

        }
