__all__ = ["lang"]

from lang.en import en
from lang.ids import ids