class config_default:
    TOKEN = ""
    DB_MODULE_ACCOUNT = ""

class config_staging:

    TOKEN = 'https://uo0t6wuhb0.execute-api.ap-northeast-1.amazonaws.com/KontraktorStaging/staging/token'
    DB_MODULE_ACCOUNT = 'https://uhl3atv9k2.execute-api.ap-northeast-1.amazonaws.com/KontraktorStaging/staging/dbmodul-account'
    DB_MODULE_ACCOUNT_NEW = 'https://93cmy8siz7.execute-api.ap-southeast-1.amazonaws.com/staging/account'
