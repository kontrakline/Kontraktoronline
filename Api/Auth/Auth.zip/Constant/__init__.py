__all__ = ["Constant"]

from Constant.config import config_staging
from Constant.config import config_default